import 'package:get/get_navigation/src/routes/get_route.dart';

import '../screens/posts/post_detail/post_detail_binding.dart';
import '../screens/posts/post_detail/post_detail_screen.dart';
import '../screens/posts/post_list/post_binding.dart';
import '../screens/posts/post_list/post_screen.dart';
import '../screens/splash/splash_screen.dart';

part 'app_routes.dart';

class AppPages {
  static List<GetPage> pages = [
    GetPage(
      name: Routes.splash,
      page: () => Splash(),
    ),
    GetPage(
        name: Routes.postList,
        page: () => const PostListScreen(),
        binding: PostBinding()),

    GetPage(
        name: Routes.postDetail,
        page: () => const PostDetailScreen(),
        binding: PostDetailBinding()
    )


  ];
}
