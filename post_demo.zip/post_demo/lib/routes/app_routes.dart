part of 'app_pages.dart';

abstract class Routes {
  static String splash = '/';
  static String postList = '/post_list';
  static String postDetail = '/post_detail';


}