import 'package:get/get.dart';
import 'package:post_demo/screens/posts/post_list/post_controller.dart';

class PostBinding extends Bindings {
  @override
  void dependencies() {
    // TODO: implement dependencies
    Get.lazyPut(() => PostController());
  }
}
