import 'package:flutter/cupertino.dart';
import 'package:get/get.dart';
import 'package:post_demo/api/api_handler.dart';
import 'package:post_demo/api/urls.dart';

import '../../../models/author_detail_model.dart';
import '../../../models/post_list_model.dart';

class PostController extends GetxController {
  var posts = <Posts>[].obs;
  ApiHandler apiHandler = ApiHandler();

  @override
  void onReady() {
    // TODO: implement onReady
    super.onReady();
    // getPosts();
  }

  @override
  void onInit() {
    super.onInit();
    getPosts();
  }

  Future<void> getPosts() async {
    try {
      final response = await apiHandler.getData(AppURLs.getPostList);
      if (response != null) {
        List<Posts> parsedPosts = (response as List)
            .map((postJson) => Posts.fromJson(postJson))
            .toList();

        posts.assignAll(parsedPosts);
      } else {
        debugPrint("API response is null");
      }
    } catch (e) {
      debugPrint("Error: $e");
    }
  }

  Future fetchAuthorName(int userId) async {
    try {
      final response = await apiHandler.getData("${AppURLs.getAuthor}$userId");
      Author author = Author.fromJson(response);
      return author.name;
    } catch (e) {
      debugPrint("Error: $e");
      return "Unknown Author";
    }
  }
}
