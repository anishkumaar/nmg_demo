import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:post_demo/screens/posts/post_list/post_controller.dart';

import '../../../routes/app_pages.dart';

class PostListScreen extends GetView<PostController> {
  const PostListScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Post List'),
      ),
      body: Obx(
        () {
          final posts = controller.posts;
          if (posts.isEmpty) {
            return const Center(child: CircularProgressIndicator());
          }
          return ListView.builder(
            padding: const EdgeInsets.symmetric(horizontal: 10,vertical: 5),
            itemCount: posts.length,
            itemBuilder: (context, index) {
              final post = posts[index];
              return Card(
                elevation: 2,
                shape: RoundedRectangleBorder(
                  side: const BorderSide(color: Colors.black12, width: 2.0),
                  borderRadius: BorderRadius.circular(10.0),
                ),
                child: ListTile(
                  title: FutureBuilder(
                    future: controller.fetchAuthorName(post.userId!),
                    builder: (context, snapshot) {
                      if (snapshot.connectionState == ConnectionState.done) {
                        return Text(snapshot.data.toString());
                      } else {
                        return const Text('Author Name Loading...');
                      }
                    },
                  ),
                  subtitle: Text(
                    post.title ?? "",
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                  onTap: () {
                    Get.toNamed(Routes.postDetail, arguments: post.id);
                  },
                ),
              );
            },
          );
        },
      ),
    );
  }
}
