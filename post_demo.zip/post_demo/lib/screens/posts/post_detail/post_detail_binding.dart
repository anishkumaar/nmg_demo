import 'package:get/get.dart';
import 'package:post_demo/screens/posts/post_detail/post_detail_controller.dart';

class PostDetailBinding extends Bindings {
  @override
  void dependencies() {
    // TODO: implement dependencies
    Get.lazyPut(() => PostDetailController());
  }
}
