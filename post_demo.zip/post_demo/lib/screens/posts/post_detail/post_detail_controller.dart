import 'package:flutter/cupertino.dart';
import 'package:get/get.dart';
import 'package:post_demo/api/api_handler.dart';
import 'package:post_demo/api/urls.dart';

import '../../../models/post_list_model.dart';

class PostDetailController extends GetxController {
  Posts selectedPost = Posts();
  ApiHandler apiHandler = ApiHandler();
  var id = Get.arguments;

  @override
  void onReady() {
    // TODO: implement onReady
    super.onReady();
  }

  @override
  void onInit() {
    super.onInit();
    getPostDetail();
  }

  Future<void> getPostDetail() async {
    try {
      final response = await apiHandler.getData("${AppURLs.getPostList}/$id");
      if (response != null) {
        selectedPost = Posts.fromJson(response);

        debugPrint("Author Posts is: $selectedPost");
      } else {
        debugPrint("API response is null");
      }
    } catch (e) {
      debugPrint("Error: $e");
    }
    update();
  }

}
