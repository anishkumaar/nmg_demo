import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:post_demo/screens/posts/post_detail/post_detail_controller.dart';

class PostDetailScreen extends StatelessWidget {
  const PostDetailScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Post Detail'),
      ),
      body: GetBuilder(
        builder: (PostDetailController controller) {
          if (controller.selectedPost.title.isNull) {
            return const Center(child: CircularProgressIndicator());
          }
          return Padding(
            padding: const EdgeInsets.all(8.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  '${controller.selectedPost.title}',
                  style: const TextStyle(
                      color: Colors.black,
                      fontSize: 18,
                      fontWeight: FontWeight.w600),
                ),
                const SizedBox(
                  height: 10,
                ),
                Text('${controller.selectedPost.body}'),
              ],
            ),
          );
        },
      ),
    );
  }
}
