import 'dart:async';

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../routes/app_pages.dart';

class SplashController extends GetxController {
  @override
  void onInit() {
    // TODO: implement onInit
    super.onInit();
    print("MyAppController");
    Timer(
      const Duration(seconds: 3),
      () {
        Get.offAllNamed(Routes.postList);
      },
    );
  }

  @override
  void onReady() {
    // TODO: implement onReady
    super.onReady();
  }
}
