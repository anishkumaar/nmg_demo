class Posts {
  int? userId;
  int? id;
  String? title;
  String? body;
  String? author;

  Posts({this.userId, this.id, this.title, this.body,this.author});

  Posts.fromJson(Map<String, dynamic> json) {
    userId = json['userId'];
    id = json['id'];
    title = json['title'];
    body = json['body'];
    author = json['authorName'];

  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['userId'] = userId;
    data['id'] = id;
    data['title'] = title;
    data['body'] = body;
    data['authorName'] = author;
    return data;
  }
}