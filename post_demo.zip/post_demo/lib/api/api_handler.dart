import 'dart:convert';

import 'package:http/http.dart' as http;

class ApiHandler {


  Future getData(uri) async {
    final response = await http.get(Uri.parse(uri));

    if (response.statusCode == 200) {
      final jsonResponse = json.decode(response.body);
      return jsonResponse;
    } else {
      throw Exception('Failed to load data from the API');
    }
  }
}
