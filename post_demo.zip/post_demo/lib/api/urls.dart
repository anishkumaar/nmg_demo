class AppURLs {
  static const String getPostList = 'https://jsonplaceholder.typicode.com/posts';
  static const String getAuthor = 'https://jsonplaceholder.typicode.com/users/';

}
