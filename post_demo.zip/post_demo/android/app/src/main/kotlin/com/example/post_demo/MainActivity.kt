package com.example.post_demo

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
